package uniandes.dpoo.taller7.interfaz4;
import javax.swing.*;

import uniandes.dpoo.taller7.modelo.RegistroTop10;
import uniandes.dpoo.taller7.modelo.Top10;

import java.awt.*;
import java.io.File;


public class Top10Interfaz extends JFrame {
    private static final long serialVersionUID = 1L;
    private Top10 top10;
    static File top_10 = new File("data/top10.csv");
    public Top10Interfaz() {
        setTitle("Top 10");
        setSize(200, 240);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        top10 = new Top10();
        top10.cargarRecords(top_10);

        JPanel panelEtiquetas = new JPanel(new GridLayout(1, 3));
        panelEtiquetas.add(new JLabel("Posici�n"));
        panelEtiquetas.add(new JLabel("Nombre"));
        panelEtiquetas.add(new JLabel("Puntaje"));

        add(panelEtiquetas, BorderLayout.NORTH);

        JPanel panelResultados = new JPanel(new GridLayout(10, 3));
        actualizarPanelResultados(panelResultados);
        add(panelResultados, BorderLayout.CENTER);
    }

    private void actualizarPanelResultados(JPanel panelResultados) {
        int posicion = 1;
        for (RegistroTop10 registro : top10.darRegistros()) {
            panelResultados.add(new JLabel(String.valueOf(posicion)));
            panelResultados.add(new JLabel(registro.darNombre()));
            panelResultados.add(new JLabel(String.valueOf(registro.darPuntos())));
            posicion++;
        }
    }

    public static void main(String[] args) {
        Top10Interfaz frame = new Top10Interfaz();
        frame.setVisible(true);
    }

    public JFrame getFrame() {
        return this;
    }
}
