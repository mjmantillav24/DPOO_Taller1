package uniandes.dpoo.taller7.interfaz2;

import javax.swing.*;
import java.awt.*;

public class PanelDerecha extends JPanel {
    private JButton btnNuevo;
    private JButton btnReiniciar;
    private JButton btnTop10;
    private JButton btnCambiarJugador;

    public PanelDerecha() {
        setLayout(new GridLayout(4, 1));
        setBackground(new Color(200, 200, 150));

        btnNuevo = new JButton("Juego Nuevo");
        btnReiniciar = new JButton("Reiniciar");
        btnTop10 = new JButton("TOP-10");
        btnCambiarJugador = new JButton("Cambiar jugador");
        add(btnNuevo);
        add(btnReiniciar);
        add(btnTop10);
        add(btnCambiarJugador);
    }

    public JButton getBtnNuevo() {
        return btnNuevo;
    }

    public JButton getBtnReiniciar() {
        return btnReiniciar;
    }

    public JButton getBtnTop10() {
        return btnTop10;
    }

    public JButton getBtnCambiarJugador() {
        return btnCambiarJugador;
    }
}