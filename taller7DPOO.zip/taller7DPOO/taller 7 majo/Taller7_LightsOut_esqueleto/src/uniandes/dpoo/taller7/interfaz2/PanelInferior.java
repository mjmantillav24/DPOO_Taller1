package uniandes.dpoo.taller7.interfaz2;


import javax.swing.*;
import java.awt.*;

public class PanelInferior extends JPanel {
    private JLabel lblJugador;
    private JLabel lblJugadas;

    public PanelInferior(String nombre) {
        setLayout(new FlowLayout());
        setBackground(new Color(200, 200, 230));

        lblJugadas = new JLabel("Jugadas: 0");
        lblJugador = new JLabel("Jugador: " + nombre);
        add(lblJugadas);
        add(lblJugador);
    }

    public void actualizarJugadas(int jugadas) {
        lblJugadas.setText("Jugadas: " + jugadas);
    }

    public void actualizarNombreJugador(String nombre) {
        lblJugador.setText("Jugador: " + nombre);
    }

    public JLabel getLblContador() {
        return lblJugadas;
    }
}