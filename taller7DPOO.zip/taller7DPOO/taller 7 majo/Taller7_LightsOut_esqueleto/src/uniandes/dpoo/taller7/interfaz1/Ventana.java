package uniandes.dpoo.taller7.interfaz1;

import uniandes.dpoo.taller7.interfaz2.*;
import uniandes.dpoo.taller7.modelo.Tablero;

import uniandes.dpoo.taller7.interfaz3.*;
import javax.swing.*;
import java.awt.*;
import java.util.Collections;
import java.util.Enumeration;

public class Ventana extends JFrame {
    private PanelSuperior panelSuperior;
    private PanelInferior panelInferior;
    private PanelDerecha panelDerecho;
    private JPanelTablero panelTablero;
    private Tablero tablerito;

    public Ventana() {
        setTitle("LightsOut");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 500);
        setLayout(new BorderLayout());

        initializeComponents();
        setupGameControls();
        setVisible(true);
    }

    private void initializeComponents() {
        // Initialize and add the superior panel
        panelSuperior = new PanelSuperior();
        add(panelSuperior, BorderLayout.NORTH);

        // Initialize and add the inferior panel
        panelInferior = new PanelInferior("Anónimo");  // Default player name
        add(panelInferior, BorderLayout.SOUTH);

        // Initialize and add the derecho panel
        panelDerecho = new PanelDerecha();
        add(panelDerecho, BorderLayout.EAST);

        // Initialize the tablero and tablero panel
        tablerito = new Tablero(5); // Default initial size of 5x5
        panelTablero = new JPanelTablero(tablerito, panelInferior.getLblContador());
        add(panelTablero, BorderLayout.CENTER);
    }

    private void setupGameControls() {
        // Size and difficulty change listeners
        panelSuperior.getTamanoCombo().addActionListener(e -> updateGameSize());
        Enumeration<AbstractButton> buttons = panelSuperior.getBtnDificultad().getElements();
        while (buttons.hasMoreElements()) {
            AbstractButton button = buttons.nextElement();
            button.addActionListener(e -> updateGameDifficulty());
        }

        // Button actions from PanelDerecho
        panelDerecho.getBtnNuevo().addActionListener(e -> startNewGame());
        panelDerecho.getBtnReiniciar().addActionListener(e -> restartGame());
        panelDerecho.getBtnTop10().addActionListener(e -> showTop10());
        panelDerecho.getBtnCambiarJugador().addActionListener(e -> changePlayer());
    }

    private void updateGameSize() {
        String sizeText = (String) panelSuperior.getTamanoCombo().getSelectedItem();
        int size = Integer.parseInt(sizeText.substring(0, 1));
        tablerito = new Tablero(size);
        panelTablero.actualizarTablero(tablerito);
    }

    private void updateGameDifficulty() {
        int difficulty = getSelectedDifficulty();
        tablerito.desordenar(difficulty);
        panelTablero.repaint();
    }

    private int getSelectedDifficulty() {
        Enumeration<AbstractButton> buttons = panelSuperior.getBtnDificultad().getElements();
        while (buttons.hasMoreElements()) {
            AbstractButton button = buttons.nextElement();
            if (button.isSelected()) {
                switch (button.getText()) {
                    case "Fácil": return 5;
                    case "Medio": return 10;
                    case "Difícil": return 15;
                }
            }
        }
        return 5;  // Default difficulty if none selected
    }

    private void startNewGame() {
        updateGameSize(); // Optionally reset the game size or difficulty here
        updateGameDifficulty();
    }

    private void restartGame() {
        tablerito.reiniciar();
        panelTablero.actualizarTablero(tablerito);
        panelInferior.actualizarJugadas(tablerito.darJugadas());
    }

    private void showTop10() {
        // Assuming you have a method or a frame to display Top 10 scores
        System.out.println("Show Top 10 Scores");
    }

    private void changePlayer() {
        String nuevoNombre = JOptionPane.showInputDialog(this, "Ingrese su nombre:");
        if (nuevoNombre != null && !nuevoNombre.trim().isEmpty()) {
            panelInferior.actualizarNombreJugador(nuevoNombre);
            panelTablero.setNombreJugador(nuevoNombre);
        }
    }

    public static void main(String[] args) {
        new Ventana();
    }
}
