package uniandes.dpoo.taller7.interfaz2;

import javax.swing.*;
import java.awt.*;

public class PanelSuperior extends JPanel {
    private JComboBox<String> tamanoCombo;
    private ButtonGroup btnDificultad;

    public PanelSuperior() {
        setLayout(new FlowLayout());
        setBackground(new Color(200, 200, 250));

        JLabel etiquetaTamano = new JLabel("Tamaño:");
        add(etiquetaTamano);

        String[] tamanos = {"3x3", "4x4", "5x5", "6x6", "7x7", "8x8"};
        tamanoCombo = new JComboBox<>(tamanos);
        add(tamanoCombo);

        JLabel etiquetaDificultad = new JLabel("Dificultad:");
        add(etiquetaDificultad);

        btnDificultad = new ButtonGroup();
        JRadioButton btnFacil = new JRadioButton("Fácil");
        JRadioButton btnMedio = new JRadioButton("Medio");
        JRadioButton btnDificil = new JRadioButton("Difícil");
        btnFacil.setSelected(true);
        btnDificultad.add(btnFacil);
        btnDificultad.add(btnMedio);
        btnDificultad.add(btnDificil);
        add(btnFacil);
        add(btnMedio);
        add(btnDificil);
    }

    public JComboBox<String> getTamanoCombo() {
        return tamanoCombo;
    }

    public ButtonGroup getBtnDificultad() {
        return btnDificultad;
    }
}

