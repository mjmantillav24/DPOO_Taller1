package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas {
	
	protected final int COSTO_POR_KM_NATURAL = 600;
	protected final int COSTO_POR_KM_CORPORATIVO = 900;
	protected final double DESCUENTO_PEQ = 0.02;
	protected final double DESCUENTO_MEDIANAS = 0.1;
	protected final double DESCUENTOS_GRANDES = 0.2;
	
	
	
	@Override
	protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		int costoBase = 0;
		int distanciaVuelo = calcularDistanciaVuelo(vuelo.getRuta());
		if (cliente.getTipoCliente().equals("Natural")) {
			costoBase = distanciaVuelo * COSTO_POR_KM_NATURAL; 
		}
		else if (cliente.getTipoCliente().equals("Corporativo")) {
			costoBase = distanciaVuelo * COSTO_POR_KM_CORPORATIVO; 
		}
		
		return costoBase;
	}

	@Override
	protected double calcularPorcentajeDescuento(Cliente cliente) {
		double descuento = 0;
		if(cliente.getTipoCliente().equals("Corporativo")) {
			ClienteCorporativo clienteCor = (ClienteCorporativo) cliente;
			if(clienteCor.getTamanoEmpresa() == 3) {
				descuento = 0.02;
			}
			if(clienteCor.getTamanoEmpresa() == 2) {
				descuento = 0.1;
			}
			if(clienteCor.getTamanoEmpresa() == 1) {
				descuento = 0.2;
			}
		}
		return descuento;
	}

}
