package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {
	public final static double IMPUESTO = 0.28;
	
	
	
	
	
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		int costoBase = calcularCostoBase(vuelo, cliente);
		double Descuento = calcularPorcentajeDescuento(cliente)/100;
		int impuestos = calcularValorImpuestos(costoBase);
		int tarifaFinal = (int) (costoBase +((Descuento)*costoBase)+(impuestos*(costoBase-Descuento)));
		return tarifaFinal;}
	
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	
	protected int calcularDistanciaVuelo(Ruta ruta) {
		int distanciaVuelo = Aeropuerto.calcularDistancia(ruta.getOrigen(),ruta.getDestino());
		return distanciaVuelo;
	}


	protected int calcularValorImpuestos(int costoBase) {
		int totalImpuesto = (int) (costoBase*(IMPUESTO/100));
		return totalImpuesto;
	}
}
