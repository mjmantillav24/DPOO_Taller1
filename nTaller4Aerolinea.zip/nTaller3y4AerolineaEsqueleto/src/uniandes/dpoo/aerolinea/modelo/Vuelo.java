package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;

import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.GeneradorTiquetes;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
	
	private String fecha;
	private Ruta ruta;
	private Avion avion;
	private Map<String,Tiquete> tiquetes;
	
	public Vuelo(Ruta ruta, String fecha, Avion avion) {
		this.ruta = ruta;
		this.fecha = fecha;
		this.avion = avion;
		this.tiquetes = new HashMap<>();
	}

	public String getFecha() {
		return this.fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public Ruta getRuta() {
		return this.ruta;
	}

	public void setRuta(Ruta ruta) {
		this.ruta = ruta;
	}

	public Avion getAvion() {
		return this.avion;
	}

	public void setAvion(Avion avion) {
		this.avion = avion;
	} 
	
	public Collection <Tiquete> getTiquetes(){
		
		return tiquetes.values();
		
	}
	
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad)throws VueloSobrevendidoException {
		int asientosDisponibles = avion.getCapacidad();
		if (cantidad > asientosDisponibles) {
            throw new VueloSobrevendidoException(null);
            
        }
		int valorTotalTiquetes = 0;
		int tarifa = calculadora.calcularTarifa(this, cliente);
		for (int i =0 ; i<cantidad;i++) {
			Tiquete tiquete = GeneradorTiquetes.generarTiquete(this, cliente, tarifa);
			GeneradorTiquetes.registrarTiquete(tiquete);
			tiquetes.put(tiquete.getCodigo(), tiquete);
			valorTotalTiquetes += tarifa;		}
		
		
		return valorTotalTiquetes;
		
	}
	
	public boolean equals (Object obj) {
		
		if (this == obj) {
			return true;
		}
		
		else {
			return false;
		}
		
		
	}
	
	
	
	
	
}    
