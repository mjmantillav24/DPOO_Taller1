package uniandes.dpoo.aerolinea.persistencia;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;

import org.json.JSONArray;
import org.json.JSONObject;

import uniandes.dpoo.aerolinea.exceptions.ClienteRepetidoException;
import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteNatural;

public class PersistenciaAerolinesJson implements IPersistenciaAerolinea {

	private static final String NOMBRE ="nombre";

	@Override
	public void cargarAerolinea(String archivo, Aerolinea aerolinea)throws IOException, InformacionInconsistenteException {
		
		
	        String jsonCompleto = new String( Files.readAllBytes( new File( archivo ).toPath( ) ) );
	        JSONObject raiz = new JSONObject( jsonCompleto );

	        cargarAerolinea( aerolinea, raiz.getJSONArray( "clientes" ) );
	
	    
	}


	@Override
	public void salvarAerolinea(String archivo, Aerolinea aerolinea) throws IOException {
		JSONObject jobject = new JSONObject( );

        
        salvarAerolinea( aerolinea, jobject );

       

        PrintWriter pw = new PrintWriter( archivo );
        jobject.write( pw, 2, 0 );
        pw.close( );
		
	}
	
	
	private void cargarAerolinea( Aerolinea aerolinea, JSONArray jAerolinea ) 
    {
        int numAerolinea = jAerolinea.length( );
        for( int i = 0; i < numAerolinea; i++ )
        {
            JSONObject aero = jAerolinea.getJSONObject( i );
            String nombre = aero.getString( NOMBRE );
           
          
        }
    }

    /**
     * Salva la información de los clientes de la aerolínea dentro del objeto json que se recibe por parámetro.
     * 
     * La información de los clientes queda dentro de la llave 'clientes'
     * @param aerolinea La aerolínea que tiene la información
     * @param jobject El objeto JSON donde debe quedar la información de los clientes
     */
    private void salvarAerolinea( Aerolinea aerolinea, JSONObject jobject )
    {
        JSONArray jAerolinea = new JSONArray( );
        
        jobject.put( "Aerolineas", jAerolinea );
    }

	

}
