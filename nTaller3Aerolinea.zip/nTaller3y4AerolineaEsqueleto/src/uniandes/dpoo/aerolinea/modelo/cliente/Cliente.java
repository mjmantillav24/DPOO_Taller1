package uniandes.dpoo.aerolinea.modelo.cliente;



import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {
	
	private List<Tiquete> tiquetesSinUsar;
	private List<Tiquete> tiquetesUsados;
	
	public Cliente() {
		this.tiquetesSinUsar = new ArrayList<>();
		this.tiquetesUsados = new ArrayList<>();
		
	}
	
	public abstract String getTipoCliente();
	public abstract String getIdentificador(); 
		
	
	public void agregarTiquete(Tiquete tiquete) {
		if (tiquete.isUsado()) {
			this.tiquetesUsados.add(tiquete);
		}
		else {
			this.tiquetesSinUsar.add(tiquete);
		}
			
	}
	public int calcularValorTotalTiquetes() {
		int valorTotalTiquetes = 0;
	    for (Tiquete tiquete : tiquetesSinUsar) {
	        valorTotalTiquetes += tiquete.getTarifa();
	    }
	    for (Tiquete tiquete : tiquetesUsados) {
	        valorTotalTiquetes += tiquete.getTarifa();
	    }
	    return valorTotalTiquetes;
		
	}
	public void usarTiquetes(Vuelo vuelo) {
		
		for (Tiquete tiquete : tiquetesSinUsar) {
            if (tiquete.getVuelo().equals(vuelo)) {
                tiquete.marcaComoUsado();
                agregarTiquete(tiquete);
            }
        }
	}
	
	
	
	
	
	
	

}
	